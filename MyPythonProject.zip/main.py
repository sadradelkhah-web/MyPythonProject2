import jdatetime
from datetime import datetime, date as py_date

from PySide6.QtCore import QDate, QDateTime, QTimer, Qt
from PySide6.QtGui import QAction, QFont, QIcon, QPainter, QPen, QPixmap, QColor
from PySide6.QtWidgets import (
    QDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QSpacerItem,
    QTabBar,
    QTabWidget,
    QVBoxLayout,
    QWidget,
    QLineEdit,
    QLayout,
    QTableWidgetItem,
    QAbstractItemView,
    QHeaderView,
)

from ui_main import Ui_MainWindow
from db_config import get_connection
from user_management import UserManagement



PERSIAN_MONTHS = [
    "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
    "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
]
PERSIAN_WEEKDAYS = ["ش", "ی", "د", "س", "چ", "پ", "ج"]


class JalaliCalendarDialog(QDialog):
    """تقویم شمسی سبک و داخلی؛ بدون نیاز به افزونه جداگانه."""
    def __init__(self, parent=None, initial_date=None, on_selected=None):
        super().__init__(parent, Qt.WindowType.Dialog)
        self.setWindowTitle("انتخاب تاریخ شمسی")
        # از Popup استفاده نمی‌کنیم؛ در ویندوز ممکن است هنگام exec فوراً بسته شود.
        self.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.setMinimumWidth(330)
        self.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.on_selected = on_selected
        try:
            self.current = jdatetime.date(
                int(initial_date[:4]), int(initial_date[4:6]), int(initial_date[6:8])
            ) if initial_date and len(initial_date) == 8 else jdatetime.date.today()
        except Exception:
            self.current = jdatetime.date.today()
        self.year = self.current.year
        self.month = self.current.month
        self._build_ui()
        self._render_days()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)
        nav = QHBoxLayout()
        self.prev_button = QPushButton("ماه قبل ◀")
        self.next_button = QPushButton("▶ ماه بعد")
        self.month_label = QLabel()
        self.month_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.month_label.setStyleSheet("font-weight: bold; font-size: 14pt;")
        nav.addWidget(self.prev_button)
        nav.addWidget(self.month_label, 1)
        nav.addWidget(self.next_button)
        root.addLayout(nav)
        self.days_grid = QGridLayout()
        self.days_grid.setSpacing(4)
        root.addLayout(self.days_grid)
        bottom = QHBoxLayout()
        today_button = QPushButton("امروز")
        clear_button = QPushButton("پاک کردن")
        bottom.addWidget(today_button)
        bottom.addWidget(clear_button)
        root.addLayout(bottom)
        self.prev_button.clicked.connect(lambda: self._change_month(-1))
        self.next_button.clicked.connect(lambda: self._change_month(1))
        today_button.clicked.connect(self._choose_today)
        clear_button.clicked.connect(self._clear_date)
        self.setStyleSheet("""
            QDialog { background: white; border: 1px solid #9AA8B7; }
            QPushButton { min-width: 32px; min-height: 30px; padding: 3px; }
            QPushButton:hover { background: #DCEBFA; }
        """)

    def _clear_grid(self):
        while self.days_grid.count():
            item = self.days_grid.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def _render_days(self):
        self._clear_grid()
        self.month_label.setText(f"{PERSIAN_MONTHS[self.month - 1]} {self.year}")
        for col, name in enumerate(PERSIAN_WEEKDAYS):
            label = QLabel(str(name))
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label.setStyleSheet("font-weight: bold; color: #245B87;")
            self.days_grid.addWidget(label, 0, col)
        first = jdatetime.date(self.year, self.month, 1)
        if self.month == 12:
            next_month = jdatetime.date(self.year + 1, 1, 1)
        else:
            next_month = jdatetime.date(self.year, self.month + 1, 1)
        day_count = (next_month - first).days
        # jdatetime.weekday: Monday=0; ستون اول تقویم شنبه است.
        start_col = (first.weekday() + 2) % 7
        for day in range(1, day_count + 1):
            button = QPushButton(str(day))
            button.setFixedSize(38, 32)
            if (self.year, self.month, day) == (self.current.year, self.current.month, self.current.day):
                button.setStyleSheet("background: #1976D2; color: white; font-weight: bold;")
            button.clicked.connect(lambda checked=False, d=day: self._choose_day(d))
            index = start_col + day - 1
            self.days_grid.addWidget(button, 1 + index // 7, index % 7)

    def _change_month(self, delta):
        month_index = self.year * 12 + (self.month - 1) + delta
        self.year, month0 = divmod(month_index, 12)
        self.month = month0 + 1
        self._render_days()

    def _choose_day(self, day):
        value = jdatetime.date(self.year, self.month, day).strftime("%Y%m%d")
        if self.on_selected:
            self.on_selected(value)
        self.accept()

    def _choose_today(self):
        self.current = jdatetime.date.today()
        self.year, self.month = self.current.year, self.current.month
        self._choose_day(self.current.day)

    def _clear_date(self):
        if self.on_selected:
            self.on_selected("")
        self.accept()


def replace_widget_in_layout(layout, old_widget, new_widget):
    """جایگزینی مطمئن ویجت حتی وقتی داخل layoutهای تو در تو باشد."""
    if layout is None:
        return False
    for index in range(layout.count()):
        item = layout.itemAt(index)
        if item is None:
            continue
        if item.widget() is old_widget:
            layout.replaceWidget(old_widget, new_widget)
            return True
        child_layout = item.layout()
        if child_layout is not None and replace_widget_in_layout(
            child_layout, old_widget, new_widget
        ):
            return True
    return False


def install_calendar_action(line_edit):
    """اگر جایگزینی ویجت ممکن نبود، تقویم را مستقیماً به همان QLineEdit وصل کن."""
    if line_edit.property("jalaliCalendarActionInstalled"):
        return
    pixmap = QPixmap(18, 18)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setPen(QPen(QColor("#245B87"), 1.4))
    painter.setBrush(QColor("#FFFFFF"))
    painter.drawRoundedRect(2, 3, 14, 13, 2, 2)
    painter.drawLine(2, 7, 16, 7)
    painter.drawLine(6, 1, 6, 5)
    painter.drawLine(12, 1, 12, 5)
    painter.setBrush(QColor("#245B87"))
    painter.setPen(Qt.PenStyle.NoPen)
    for x, y in ((5, 9), (9, 9), (5, 12), (9, 12)):
        painter.drawRect(x, y, 2, 2)
    painter.end()
    action = QAction(QIcon(pixmap), "انتخاب تاریخ شمسی", line_edit)
    action.setToolTip("انتخاب تاریخ شمسی")
    line_edit.addAction(action, QLineEdit.ActionPosition.TrailingPosition)

    def open_calendar():
        raw = normalize_digits(line_edit.text()).strip()
        digits = "".join(ch for ch in raw if ch.isdigit())
        if len(digits) != 8:
            digits = ""

        def set_date(value):
            line_edit.setText(
                f"{value[:4]}/{value[4:6]}/{value[6:8]}" if value else ""
            )

        try:
            dialog = JalaliCalendarDialog(line_edit, digits, set_date)
            dialog.exec()
        except Exception as exc:
            QMessageBox.critical(
                line_edit.window(), "خطای تقویم شمسی",
                f"پنجره تقویم باز نشد:\n{exc}"
            )

    # صریحاً آرگومان checked سیگنال QAction را نادیده بگیر.
    action.triggered.connect(lambda checked=False: open_calendar())
    line_edit.setProperty("jalaliCalendarActionInstalled", True)


class JalaliDateLineEdit(QLineEdit):
    """فیلد تاریخ شمسی با یک آیکون تقویم داخل خود فیلد."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.setPlaceholderText("شمسی: 1405/07/18")
        # آیکون تقویم به‌صورت واقعی رسم می‌شود تا در ویندوز وابسته به فونت Emoji نباشد.
        pixmap = QPixmap(18, 18)
        pixmap.fill(Qt.GlobalColor.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(QPen(QColor("#245B87"), 1.4))
        painter.setBrush(QColor("#FFFFFF"))
        painter.drawRoundedRect(2, 3, 14, 13, 2, 2)
        painter.drawLine(2, 7, 16, 7)
        painter.drawLine(6, 1, 6, 5)
        painter.drawLine(12, 1, 12, 5)
        painter.setBrush(QColor("#245B87"))
        painter.setPen(Qt.PenStyle.NoPen)
        for x, y in ((5, 9), (9, 9), (5, 12), (9, 12)):
            painter.drawRect(x, y, 2, 2)
        painter.end()
        self.calendar_action = QAction(QIcon(pixmap), "انتخاب تاریخ شمسی", self)
        self.calendar_action.setToolTip("انتخاب تاریخ شمسی")
        self.addAction(self.calendar_action, QLineEdit.ActionPosition.TrailingPosition)
        # QAction.triggered یک مقدار bool هم می‌فرستد؛ اتصال بدون ابهام انجام شود.
        self.calendar_action.triggered.connect(
            lambda checked=False: self.open_calendar()
        )

    def open_calendar(self):
        raw = normalize_digits(self.text()).strip()
        digits = "".join(ch for ch in raw if ch.isdigit())
        if len(digits) != 8:
            digits = ""
        try:
            dialog = JalaliCalendarDialog(self, digits, self._set_selected_date)
            dialog.exec()
        except Exception as exc:
            QMessageBox.critical(
                self.window(), "خطای تقویم شمسی",
                f"پنجره تقویم باز نشد:\n{exc}"
            )

    def _set_selected_date(self, value):
        if value:
            self.setText(f"{value[:4]}/{value[4:6]}/{value[6:8]}")
        else:
            self.clear()


# ==================================================
# تبدیل ارقام فارسی و عربی به انگلیسی
# ==================================================

def normalize_digits(value):
    if value is None:
        return ""

    value = str(value)

    translation_table = str.maketrans(
        "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩",
        "01234567890123456789"
    )

    return value.translate(translation_table)


def normalize_status(value):
    """یکسان‌سازی متن وضعیت برای جلوگیری از خطاهای فاصله و حروف فارسی/عربی."""
    value = str(value or "").strip()
    value = value.replace("ي", "ی").replace("ك", "ک")
    value = value.replace("‌", "").replace("‏", "").replace("‎", "")
    value = "".join(value.split())
    key = value.casefold()
    aliases = {
        "ثبتنشده": "ثبت نشده",
        "درانتظاربررسی": "در انتظار بررسی",
        "درحالح انجام": "در حال انجام",
        "درحالح انجام": "در حال انجام",
        "درحالت انجام": "در حال انجام",
        "درحالانجام": "در حال انجام",
        "متوقفشده": "متوقف شده",
        "پایان": "پایان",
        "تکمیلشده": "پایان",
    }
    return aliases.get(key, value)


# ==================================================
# واحدها
# ==================================================

UNIT_MAPPING = {
    "tamerat": "تعمیرات عمومی",
    "kala": "تدارکات کالا",
    "khadamat": "خدمات اداری و اجتماعی",
    "hse": "ایمنی",
    "harasat": "حراست",
}

PERSIAN_UNITS = set(UNIT_MAPPING.values())


def map_unit_name(value):
    value = str(value or "").strip()
    if not value:
        return ""
    mapped = UNIT_MAPPING.get(value.casefold())
    if mapped:
        return mapped
    if value in PERSIAN_UNITS:
        return value
    return value


# ==================================================
# کلاس اصلی فرم
# ==================================================


# -----------------------------
# تبدیل تاریخ میلادی به شمسی
# -----------------------------
def gregorian_to_jalali(gy, gm, gd):
    g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]

    gy2 = gy + 1 if gm > 2 else gy
    days = (
        355666
        + 365 * gy
        + (gy2 + 3) // 4
        - (gy2 + 99) // 100
        + (gy2 + 399) // 400
        + gd
        + g_d_m[gm - 1]
    )

    jy = -1595 + 33 * (days // 12053)
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461

    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365

    if days < 186:
        jm = 1 + days // 31
        jd = 1 + days % 31
    else:
        jm = 7 + (days - 186) // 30
        jd = 1 + (days - 186) % 30

    return jy, jm, jd


PERSIAN_WEEKDAYS = {
    1: "دوشنبه",
    2: "سه‌شنبه",
    3: "چهارشنبه",
    4: "پنجشنبه",
    5: "جمعه",
    6: "شنبه",
    7: "یکشنبه",
}


class MainWindow(QMainWindow):
    def __init__(self, user):
        super().__init__()
        self.user = user
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.open_forms = {}
        self.is_master = str(self.user.get("usersecurity") or "").strip().casefold() == "superadmin"
        self.username = str(self.user.get("username") or "").strip()
        self.usersecurity = str(self.user.get("usersecurity") or "").strip()
        self.userlevel = str(self.user.get("Userlevel") or "").strip()
        self.user_vahed = map_unit_name(self.user.get("vahed", ""))
        self.user_samat = str(self.user.get("Samat") or "").strip()
        self.setWindowTitle("سامانه مدیریت درخواست‌های تعمیرات")
        self.setLayoutDirection(Qt.RightToLeft)
        self.setup_status_bar()
        self.build_application_shell()
        self.build_menus()
        self.setup_kar_tab()
        self.setup_report_tab()
        self.load_kar_list()
        self.load_report_data()
        self.update_clock()
        self.clock_timer = QTimer(self)
        self.clock_timer.timeout.connect(self.update_clock)
        self.clock_timer.start(1000)
        self.showMaximized()

    # -----------------------------
    # نوار وضعیت
    # -----------------------------
    def setup_status_bar(self):
        status_bar = self.statusBar()
        status_bar.setMinimumHeight(32)
        status_bar.setSizeGripEnabled(False)
        status_bar.show()

        # برچسب‌های نوار وضعیت را خود برنامه می‌سازد تا وابسته به
        # وجود یا نام‌گذاری آنها در main.ui نباشیم.
        self.lblStatusUser = QLabel()
        self.lblStatusUnit = QLabel()
        self.lblStatusSecurity = QLabel()
        self.lblStatusLevel = QLabel()
        self.lblStatusWeekday = QLabel()
        self.lblStatusDate = QLabel()
        self.lblStatusTime = QLabel()

        status_labels = (
            self.lblStatusUser,
            self.lblStatusUnit,
            self.lblStatusSecurity,
            self.lblStatusLevel,
            self.lblStatusWeekday,
            self.lblStatusDate,
            self.lblStatusTime,
        )

        for label in status_labels:
            label.setTextInteractionFlags(Qt.NoTextInteraction)
            label.setMinimumWidth(70)
            label.setAlignment(Qt.AlignCenter)
            status_bar.addWidget(label)

        username = str(self.user.get("username") or "").strip()
        vahed = str(self.user.get("vahed") or "").strip()
        user_security = str(self.user.get("usersecurity") or "").strip()
        user_level = str(self.user.get("Userlevel") or "").strip()

        self.lblStatusUser.setText(f"کاربر: {username}")
        self.lblStatusUnit.setText(f"واحد: {vahed}")
        self.lblStatusSecurity.setText(f"نوع کاربر: {user_security}")
        self.lblStatusLevel.setText(f"سطح دسترسی: {user_level}")

    def update_clock(self):
        now = QDateTime.currentDateTime()
        d = now.date()

        jy, jm, jd = gregorian_to_jalali(d.year(), d.month(), d.day())
        weekday = PERSIAN_WEEKDAYS.get(d.dayOfWeek(), "")

        self.lblStatusWeekday.setText(weekday)
        self.lblStatusDate.setText(f"{jy:04d}/{jm:02d}/{jd:02d}")
        self.lblStatusTime.setText(now.toString("HH:mm:ss"))

    # -----------------------------
    # پوسته اصلی برنامه
    # -----------------------------
    def build_application_shell(self):
        """ناوبری برنامه: در شروع فقط صفحه اصلی نمایش داده می‌شود."""
        self.tabMain = self.ui.tabMain
        self.home_widget = self.ui.tabHome
        self.open_forms = getattr(self, "open_forms", {})
        self.tabMain.setTabsClosable(False)
        self.tabMain.setMovable(False)
        self.tabMain.setDocumentMode(False)
        self.tabMain.setLayoutDirection(Qt.RightToLeft)
        self.tabMain.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.tabMain.tabBar().setExpanding(True)
        self.tabMain.tabBar().setUsesScrollButtons(False)
        self.tabMain.currentChanged.connect(self._on_main_tab_changed)

        self.ui.lblNavigationUser.setText(f"خوش آمدید\n{self.username}")

        # اتصال دکمه‌های منوی کناری
        self.ui.btnHome.clicked.connect(self.show_home)
        self.ui.btnPassword.clicked.connect(self.open_password_form)
        self.ui.btnUsers.clicked.connect(self.open_user_management)
        self.ui.btnRepairs.clicked.connect(lambda: self.open_page(self.ui.tabKar))
        self.ui.btnEquipment.clicked.connect(lambda: self.open_placeholder("تجهیزات"))
        self.ui.btnReports.clicked.connect(lambda: self.open_page(self.ui.tabReport))
        self.ui.btnExit.clicked.connect(self.close)

        # دکمه‌های داخل صفحه اصلی
        self.ui.btnOpenKar.clicked.connect(lambda: self.open_page(self.ui.tabKar))
        self.ui.btnOpenUsers.clicked.connect(self.open_user_management)
        self.ui.btnOpenPassword.clicked.connect(self.open_password_form)
        self.ui.btnOpenReports.clicked.connect(lambda: self.open_page(self.ui.tabReport))
        self.ui.btnOpenEquipment.clicked.connect(lambda: self.open_placeholder("تجهیزات"))

        # دکمه خروج از هر تب به صفحه اصلی
        self.exit_tab_buttons = (
            self.ui.btnBackHomeKar,
            self.ui.btnBackHomeUsers,
            self.ui.btnBackHomePassword,
            self.ui.btnBackHomeReport,
        )
        for button in self.exit_tab_buttons:
            button.setText("خروج از این تب")
            button.setToolTip("بستن این بخش و بازگشت به صفحه اصلی")
            button.clicked.connect(self.show_home)

        # مدیریت کاربران فقط برای SuperAdmin نمایش داده می‌شود.
        self.ui.btnUsers.setVisible(self.is_master)
        self.ui.btnOpenUsers.setVisible(self.is_master)

        # در شروع فقط صفحه اصلی قابل مشاهده باشد؛ بقیه تب‌ها هنگام درخواست باز می‌شوند.
        self.show_home()

    # -----------------------------
    # منوها
    # -----------------------------
    def build_menus(self):
        """اتصال منوهای برنامه به همان توابع ناوبری دکمه‌ها."""
        ui = self.ui
        ui.actionHome.triggered.connect(self.show_home)
        ui.actionPassword.triggered.connect(self.open_password_form)
        ui.actionExit.triggered.connect(self.close)
        ui.actionUserManagement.triggered.connect(self.open_user_management)
        ui.actionRepairsRequest.triggered.connect(
            lambda checked=False: self.open_page(self.ui.tabKar)
        )
        ui.actionRepairsHistory.triggered.connect(
            lambda checked=False: self.open_page(self.ui.tabKar)
        )
        ui.actionEquipmentList.triggered.connect(
            lambda checked=False: self.open_placeholder("تجهیزات")
        )
        ui.actionReportRepairs.triggered.connect(
            lambda checked=False: self.open_page(self.ui.tabReport)
        )
        ui.actionReportEquipment.triggered.connect(
            lambda checked=False: self.open_page(self.ui.tabReport)
        )
        ui.actionAbout.triggered.connect(self.show_about)
        ui.menuUsers.menuAction().setVisible(self.is_master)
        ui.actionUserManagement.setVisible(self.is_master)

    # -----------------------------
    # مدیریت نمایش صفحه‌ها
    # -----------------------------
    def show_page(self, page):
        """صفحه اصلی و فقط صفحه انتخاب‌شده را نمایش بده."""
        index = self.tabMain.indexOf(page)
        if index < 0:
            QMessageBox.warning(self, "خطای صفحه", "صفحه موردنظر در tabMain پیدا نشد.")
            return
        home_index = self.tabMain.indexOf(self.home_widget)
        for i in range(self.tabMain.count()):
            widget = self.tabMain.widget(i)
            self.tabMain.setTabVisible(i, widget is self.home_widget or widget is page)
        if home_index >= 0 and page is self.home_widget:
            self.tabMain.setCurrentIndex(home_index)
        else:
            self.tabMain.setCurrentWidget(page)

    def open_page(self, page):
        """باز کردن یک بخش؛ فقط تب صفحه اصلی و تب انتخاب‌شده قابل مشاهده‌اند."""
        self.show_page(page)

    def show_home(self):
        """بازگشت به صفحه اصلی و پنهان کردن تمام بخش‌های دیگر."""
        home_index = self.tabMain.indexOf(self.home_widget)
        for i in range(self.tabMain.count()):
            self.tabMain.setTabVisible(i, self.tabMain.widget(i) is self.home_widget)
        if home_index >= 0:
            self.tabMain.setCurrentIndex(home_index)

    def _on_main_tab_changed(self, index):
        """اگر کاربر از نوار تب به صفحه اصلی برگشت، تب‌های دیگر پنهان شوند."""
        if index >= 0 and self.tabMain.widget(index) is self.home_widget:
            for i in range(self.tabMain.count()):
                self.tabMain.setTabVisible(i, self.tabMain.widget(i) is self.home_widget)

    def open_user_management(self):
        # تب «مدیریت کاربران» فقط برای SuperAdmin مجاز است.
        if not self.is_master:
            QMessageBox.warning(
                self,
                "عدم دسترسی",
                "فقط SuperAdmin مجاز به دسترسی به مدیریت کاربران است."
            )
            return
        self.open_management_form(password_only=False)

    def open_password_form(self):
        self.open_management_form(password_only=True)

    def open_management_form(self, password_only=False):
        """باز کردن تب‌های طراحی‌شده در main.ui؛ UserManagement کنترلر است، نه ویجت."""
        if not password_only and not self.is_master:
            QMessageBox.warning(
                self,
                "عدم دسترسی",
                "فقط SuperAdmin مجاز به دسترسی به تب کاربران است."
            )
            return

        # کنترلر فقط یک بار ساخته شود؛ خودش سیگنال دکمه‌های فرم را متصل می‌کند.
        if not hasattr(self, "user_management_controller"):
            self.user_management_controller = UserManagement(
                parent_window=self,
                ui=self.ui,
                current_user=self.user,
            )

        if password_only:
            target = self.ui.tabChangePassword
            title = "تغییر رمز عبور"
        else:
            target = self.ui.tabUserManagement
            title = "مدیریت کاربران"

        index = self.tabMain.indexOf(target)
        if index < 0:
            QMessageBox.warning(
                self,
                "خطای فرم",
                f"تب «{title}» در main.ui پیدا نشد. نام ویجت را در Qt Designer بررسی کن."
            )
            return

        self.show_page(target)

    def remove_form_tab(self, widget):
        """سازگاری با کنترلر مدیریت کاربران؛ تب‌های اصلی حذف نمی‌شوند."""
        if widget in (self.home_widget, self.ui.tabKar, self.ui.tabUserManagement,
                      self.ui.tabChangePassword, self.ui.tabReport):
            self.show_home()
            return
        index = self.tabMain.indexOf(widget)
        if index >= 0:
            self.tabMain.removeTab(index)
        self.show_home()

    def open_placeholder(self, title):
        if title in ("درخواست کار", "تعمیرات", "سوابق تعمیرات"):
            self.show_page(self.ui.tabKar)
            return
        if title in ("گزارش و پیگیری", "گزارش‌ها", "گزارش تعمیرات", "گزارش تجهیزات"):
            self.show_page(self.ui.tabReport)
            return

        key = f"placeholder:{title}"
        existing = self.open_forms.get(key)
        if existing is not None:
            index = self.tabMain.indexOf(existing)
            if index >= 0:
                self.show_page(existing)
                return
            self.open_forms.pop(key, None)

        page = QWidget()
        page.setObjectName(f"page_{title}")
        page.setLayoutDirection(Qt.RightToLeft)
        layout = QVBoxLayout(page)
        layout.setContentsMargins(30, 20, 30, 30)

        back_button = QPushButton("بازگشت به صفحه اصلی")
        back_button.setMinimumHeight(36)
        back_button.setMaximumWidth(190)
        back_button.clicked.connect(lambda checked=False, p=page: self.close_dynamic_page(p))
        layout.addWidget(back_button, 0, Qt.AlignRight)

        lbl_title = QLabel(title)
        font = QFont()
        font.setPointSize(20)
        font.setBold(True)
        lbl_title.setFont(font)
        lbl_title.setAlignment(Qt.AlignCenter)
        layout.addWidget(lbl_title)

        lbl_text = QLabel("این بخش هنوز فرم اختصاصی ندارد و برای توسعه بعدی آماده است.")
        lbl_text.setAlignment(Qt.AlignCenter)
        lbl_text.setWordWrap(True)
        layout.addWidget(lbl_text)
        layout.addItem(QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding))

        self.tabMain.addTab(page, title)
        self.open_forms[key] = page
        self.show_page(page)

    def close_dynamic_page(self, page):
        index = self.tabMain.indexOf(page)
        if index >= 0:
            self.tabMain.removeTab(index)
        for key, value in list(self.open_forms.items()):
            if value is page:
                self.open_forms.pop(key, None)
        page.deleteLater()
        self.show_home()

    def show_about(self):
        QMessageBox.information(
            self,
            "درباره برنامه",
            "سامانه مدیریت\n\nنسخه اولیه مدیریت کاربران و ماژول‌های برنامه",
        )


    @staticmethod
    def format_jalali_input_date(value):
        digits = normalize_digits(value)
        digits = "".join(ch for ch in digits if ch.isdigit())
        if len(digits) == 8:
            return f"{digits[:4]}/{digits[4:6]}/{digits[6:8]}"
        return str(value or "")

    @staticmethod
    def jalali_storage_date(value):
        digits = normalize_digits(value)
        return "".join(ch for ch in digits if ch.isdigit())

    def setup_kar_tab(self):
        # فیلد تاریخ درخواست را به فیلد دارای تقویم شمسی تبدیل کن.
        self.setup_request_date_calendar()

        # بارگذاری گزینه‌های واحد و موضوع؛ در UI فقط خود کمبوباکس‌ها طراحی شده‌اند.
        self.load_request_comboboxes()

        self.ui.dateTarikhdarkhast.setText(
            jdatetime.date.today().strftime("%Y/%m/%d")
        )

        table = self.ui.tblKarList

        table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows
        )

        table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection
        )

        table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers
        )

        # مخفی کردن شماره‌گذاری خودکار سمت چپ
        table.verticalHeader().setVisible(False)

        # فونت عنوان ستون‌ها
        header = table.horizontalHeader()

        header_font = QFont("B Nazanin", 14)
        header_font.setBold(True)

        header.setFont(header_font)
        header.setMinimumHeight(42)

        header.setSectionResizeMode(
            QHeaderView.ResizeMode.Interactive
        )

        header.setStyleSheet("""
            QHeaderView::section {
                background-color: #E8EEF5;
                color: #1F2937;
                font-family: "B Nazanin";
                font-size: 14pt;
                font-weight: bold;
                padding: 7px;
                border: 1px solid #C7D0DB;
            }

            QHeaderView::section:hover {
                background-color: #DCE6F1;
            }
        """)

        # ظاهر جدول
        table.setAlternatingRowColors(True)

        table.setStyleSheet("""
            QTableWidget {
                background-color: white;
                alternate-background-color: #F7F9FC;
                gridline-color: #D6DCE3;
                border: 1px solid #C7D0DB;
                border-radius: 6px;
                font-family: "B Nazanin";
                font-size: 12pt;
                selection-background-color: #B8D7F0;
                selection-color: #000000;
            }

            QTableWidget::item {
                padding: 5px;
                border: none;
            }

            QTableWidget::item:selected {
                background-color: #B8D7F0;
                color: #000000;
            }
        """)

        table.verticalHeader().setDefaultSectionSize(34)

        # اتصال دکمه‌ها
        self.ui.btnSaveKar.clicked.connect(self.save_kar)
        self.ui.btnNewKar.clicked.connect(self.new_kar)
        self.ui.btnClearKar.clicked.connect(self.clear_kar)

        self.ui.txtSearchKar.textChanged.connect(
            self.search_kar
        )

    def setup_request_date_calendar(self):
        """فیلد طراحی‌شده در main.ui را با فیلد دارای تقویم شمسی جایگزین می‌کند."""
        old_widget = getattr(self.ui, "dateTarikhdarkhast", None)
        if old_widget is None or isinstance(old_widget, JalaliDateLineEdit):
            return

        parent = old_widget.parentWidget()
        layout = parent.layout() if parent is not None else None
        new_widget = JalaliDateLineEdit(parent)
        new_widget.setObjectName("dateTarikhdarkhast")
        new_widget.setText(old_widget.text())
        new_widget.setMinimumWidth(max(140, old_widget.minimumWidth()))
        new_widget.setSizePolicy(old_widget.sizePolicy())

        if not replace_widget_in_layout(layout, old_widget, new_widget):
            new_widget.deleteLater()
            old_widget.setPlaceholderText("برای انتخاب تاریخ روی فیلد تاریخ دوبار کلیک کنید")
            old_widget.setProperty("jalaliCalendarUnavailable", True)
            # جایگزین مطمئن: با دوبار کلیک روی خود فیلد، تقویم باز شود.
            install_calendar_action(old_widget)
            return

        old_widget.hide()
        old_widget.setParent(None)
        old_widget.deleteLater()
        self.ui.dateTarikhdarkhast = new_widget

    def load_request_comboboxes(self):
        """پر کردن کمبوباکس‌های درخواست کار با واحدها و موضوعات موجود."""
        unit_combo = self.ui.cmbVahed
        previous_unit = map_unit_name(unit_combo.currentText())
        unit_combo.setEnabled(True)
        unit_combo.clear()
        unit_combo.addItem("", "")
        for unit in sorted(PERSIAN_UNITS):
            unit_combo.addItem(unit, unit)

        topic_combo = self.ui.cmbMozooe
        previous_topic = topic_combo.currentText().strip()
        topics = []
        conn = None
        cursor = None
        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute(
                "SELECT DISTINCT mozooe FROM tblkar "
                "WHERE mozooe IS NOT NULL AND Trim(mozooe) <> '' "
                "ORDER BY mozooe"
            )
            topics = [str(row[0]).strip() for row in cursor.fetchall() if row[0] and str(row[0]).strip()]
        except Exception:
            # اگر جدول هنوز موضوعی نداشته باشد یا دیتابیس موقتاً در دسترس نباشد،
            # فهرست اولیه نمایش داده می‌شود.
            topics = []
        finally:
            try:
                if cursor:
                    cursor.close()
            except Exception:
                pass
            try:
                if conn:
                    conn.close()
            except Exception:
                pass

        if not topics:
            topics = ["برق", "مکانیک", "تأسیسات", "ساختمانی", "ابزار دقیق", "سایر"]
        topics = list(dict.fromkeys(topics))
        topic_combo.clear()
        topic_combo.addItem("", "")
        for topic in topics:
            topic_combo.addItem(topic, topic)

        # برای کاربران عادی، واحد خودشان انتخاب شود و امکان تغییر واحد نداشته باشند.
        if self.usersecurity.casefold() != "superadmin" and self.user_vahed:
            index = unit_combo.findData(self.user_vahed)
            if index < 0:
                index = unit_combo.findText(self.user_vahed)
            if index >= 0:
                unit_combo.setCurrentIndex(index)
                unit_combo.setEnabled(False)
            else:
                unit_combo.setCurrentIndex(0)
                unit_combo.setEnabled(True)
        elif previous_unit:
            index = unit_combo.findText(previous_unit)
            if index >= 0:
                unit_combo.setCurrentIndex(index)

        if previous_topic:
            index = topic_combo.findText(previous_topic)
            if index >= 0:
                topic_combo.setCurrentIndex(index)
        else:
            topic_combo.setCurrentIndex(0)

    def get_next_wonumber(self):

        conn = None
        cursor = None

        try:

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                SELECT MAX(VAL(wonumber))
                FROM tblkar
            """)

            result = cursor.fetchone()

            if result is None or result[0] is None:
                return 1

            return int(result[0]) + 1

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در دریافت شماره درخواست:\n{e}"
            )

            return 1

        finally:

            try:
                if cursor:
                    cursor.close()
            except Exception:
                pass

            try:
                if conn:
                    conn.close()
            except Exception:
                pass

    def new_kar(self):

        self.clear_kar()

        wonumber = self.get_next_wonumber()

        self.ui.lblWonumber.setText(str(wonumber))

        self.ui.dateTarikhdarkhast.setText(
            jdatetime.date.today().strftime("%Y/%m/%d")
        )

        if self.usersecurity.lower() != "superadmin":

            if self.user_vahed:

                index = self.ui.cmbVahed.findText(
                    self.user_vahed
                )

                if index >= 0:
                    self.ui.cmbVahed.setCurrentIndex(index)

                self.ui.cmbVahed.setEnabled(False)

        else:

            self.ui.cmbVahed.setEnabled(True)

    def clear_kar(self):

        self.ui.cmbMozooe.setCurrentIndex(0)
        self.ui.txtMahalkarf.clear()
        self.ui.txtMahalkara.clear()
        self.ui.txtSharh.clear()

        self.ui.dateTarikhdarkhast.setText(
            jdatetime.date.today().strftime("%Y/%m/%d")
        )

        if self.usersecurity.lower() != "superadmin":

            if self.user_vahed:

                index = self.ui.cmbVahed.findText(
                    self.user_vahed
                )

                if index >= 0:
                    self.ui.cmbVahed.setCurrentIndex(index)

                self.ui.cmbVahed.setEnabled(False)

        else:

            self.ui.cmbVahed.setEnabled(True)

    def save_kar(self):

        wonumber = self.ui.lblWonumber.text().strip()
        vahed = str(self.ui.cmbVahed.currentData() or self.ui.cmbVahed.currentText()).strip()

        tarikhdarkhast_display = self.ui.dateTarikhdarkhast.text().strip()
        tarikhdarkhast = self.jalali_storage_date(tarikhdarkhast_display)

        # تاریخ برای ذخیره باید دقیقاً YYYYMMDD باشد؛
        # اما در فرم کاربر آن را به صورت YYYY/MM/DD می‌بیند.
        if len(tarikhdarkhast) != 8 or not tarikhdarkhast.isdigit():
            QMessageBox.warning(
                self,
                "تاریخ نامعتبر",
                "تاریخ درخواست را به صورت 1405/07/18 وارد کنید."
            )
            return

        mozooe = str(self.ui.cmbMozooe.currentData() or self.ui.cmbMozooe.currentText()).strip()
        mahalkarf = self.ui.txtMahalkarf.text().strip()
        mahalkara = self.ui.txtMahalkara.text().strip()
        sharh = self.ui.txtSharh.toPlainText().strip()
        darkhastkonande = self.username

        if not wonumber:
            QMessageBox.warning(
                self,
                "هشدار",
                "شماره درخواست مشخص نیست."
            )
            return

        if not vahed:
            QMessageBox.warning(
                self,
                "هشدار",
                "لطفاً واحد را انتخاب کنید."
            )
            return

        if not tarikhdarkhast:
            QMessageBox.warning(
                self,
                "هشدار",
                "تاریخ درخواست مشخص نیست."
            )
            return

        if not mozooe:
            QMessageBox.warning(
                self,
                "هشدار",
                "لطفاً موضوع درخواست را انتخاب کنید."
            )
            return

        if not mahalkarf:
            QMessageBox.warning(
                self,
                "هشدار",
                "لطفاً محل کار را وارد کنید."
            )
            return

        if not sharh:
            QMessageBox.warning(
                self,
                "هشدار",
                "لطفاً شرح درخواست را وارد کنید."
            )
            return

        if self.usersecurity.lower() != "superadmin":

            if vahed != self.user_vahed:
                QMessageBox.warning(
                    self,
                    "عدم دسترسی",
                    "شما فقط مجاز به ثبت درخواست برای واحد خود هستید."
                )
                return

        conn = None
        cursor = None

        try:

            conn = get_connection()
            cursor = conn.cursor()

            cursor.execute("""
                INSERT INTO tblkar
                (
                    wonumber,
                    vahed,
                    tarikhdarkhast,
                    mozooe,
                    mahalkarf,
                    mahalkara,
                    sharh,
                    darkhastkonande,
                    vaziyat,
                    payan,
                    tarikh,
                    editor,
                    sharhepey
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                wonumber,
                vahed,
                int(tarikhdarkhast),
                mozooe,
                mahalkarf,
                mahalkara,
                sharh,
                darkhastkonande,
                "ثبت نشده",
                False,
                None,
                self.username,
                ""
            ))

            conn.commit()

            QMessageBox.information(
                self,
                "ثبت درخواست",
                "درخواست با موفقیت ثبت شد."
            )

            self.load_kar_list()
            self.new_kar()

        except Exception as e:

            if conn:
                try:
                    conn.rollback()
                except Exception:
                    pass

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در ثبت درخواست:\n{e}"
            )

        finally:

            try:
                if cursor:
                    cursor.close()
            except Exception:
                pass

            try:
                if conn:
                    conn.close()
            except Exception:
                pass

    def load_kar_list(self):

        try:
            search_text = self.ui.txtSearchKar.text().strip()
        except Exception:
            search_text = ""

        self.load_kar_data(search_text)

    def search_kar(self):

        search_text = self.ui.txtSearchKar.text().strip()

        self.load_kar_data(search_text)

    def load_kar_data(self, search_text=""):

        table = self.ui.tblKarList

        conn = None
        cursor = None

        try:

            conn = get_connection()
            cursor = conn.cursor()

            is_superadmin = (
                self.usersecurity.lower() == "superadmin"
            )

            is_admin = (
                self.usersecurity.lower() == "admin"
            )

            query = """
                SELECT
                    [wonumber],
                    [vahed],
                    [tarikhdarkhast],
                    [mozooe],
                    [mahalkara],
                    [mahalkarf],
                    [darkhastkonande],
                    [sharh],
                    [vaziyat],
                    [tarikh],
                    [sharhepey]
                FROM [tblkar]
            """

            conditions = []
            params = []

            # محدودیت دسترسی
            if is_superadmin:
                pass

            elif is_admin:

                if self.user_vahed:
                    conditions.append("[vahed] = ?")
                    params.append(self.user_vahed)

            else:

                conditions.append("[darkhastkonande] = ?")
                params.append(self.username)

            # جستجو در ستون‌ها
            if search_text:

                normalized_search = normalize_digits(search_text)

                search_conditions = [
                    "[vahed] LIKE ?",
                    "[mozooe] LIKE ?",
                    "[mahalkarf] LIKE ?",
                    "[mahalkara] LIKE ?",
                    "[sharh] LIKE ?",
                    "[darkhastkonande] LIKE ?",
                ]

                for _ in search_conditions:
                    params.append(f"%{search_text}%")

                if normalized_search.isdigit():

                    search_conditions.append(
                        "VAL(wonumber) = ?"
                    )

                    params.append(int(normalized_search))

                conditions.append(
                    "(" + " OR ".join(search_conditions) + ")"
                )

            if conditions:
                query += " WHERE " + " AND ".join(conditions)

            query += " ORDER BY [id] DESC"

            cursor.execute(query, params)

            rows = cursor.fetchall()

            headers = [
                "شماره ردیف",
                "شماره درخواست",
                "واحد",
                "تاریخ درخواست",
                "موضوع",
                "محل کار",
                "محل کار فرعی",
                "درخواست‌کننده",
                "شرح",
                "وضعیت",
                "تاریخ پیگیری",
                "شرح پیگیری",
            ]

            table.clear()
            table.setColumnCount(len(headers))
            table.setHorizontalHeaderLabels(headers)
            table.setRowCount(len(rows))

            for row_index, row in enumerate(rows):

                # شماره ردیف نمایشی
                table.setItem(
                    row_index,
                    0,
                    QTableWidgetItem(str(row_index + 1))
                )

                # اطلاعات دیتابیس
                for col_index, value in enumerate(row):

                    if value is None:
                        value = ""

                    # تبدیل تاریخ به نمایش YYYY/MM/DD
                    if col_index == 2 and value != "":

                        value = normalize_digits(value)
                        value = str(value)

                        if len(value) == 8 and value.isdigit():

                            value = (
                                value[:4]
                                + "/"
                                + value[4:6]
                                + "/"
                                + value[6:]
                            )

                    item = QTableWidgetItem(str(value))

                    item.setTextAlignment(
                        Qt.AlignmentFlag.AlignRight
                        | Qt.AlignmentFlag.AlignVCenter
                    )

                    table.setItem(
                        row_index,
                        col_index + 1,
                        item
                    )

                # راست‌چین کردن شماره ردیف
                first_item = table.item(row_index, 0)

                if first_item:
                    first_item.setTextAlignment(
                        Qt.AlignmentFlag.AlignCenter
                    )

            # عرض اولیه ستون‌ها؛ کاربر می‌تواند بعداً تغییر دهد
            column_widths = [
                80,
                110,
                180,
                120,
                180,
                160,
                160,
                140,
                350,
                120,
                120,
                300,
            ]

            for index, width in enumerate(column_widths):
                table.setColumnWidth(index, width)

        except Exception as e:

            QMessageBox.critical(
                self,
                "خطا",
                f"خطا در دریافت لیست درخواست‌ها:\n{e}"
            )

        finally:

            try:
                if cursor:
                    cursor.close()
            except Exception:
                pass

            try:
                if conn:
                    conn.close()
            except Exception:
                pass

    def is_maintenance_unit(self):
        return self.user_vahed == "تعمیرات عمومی"

    def can_manage_tracking(self):
        return (
            self.usersecurity.casefold() == "superadmin"
            or self.is_maintenance_unit()
        )

    def ensure_tracking_table(self):
        """سازگاری با نسخه‌های قبلی؛ پیگیری‌ها اکنون مستقیماً در tblkar ذخیره می‌شوند."""
        return

    def setup_report_tab(self):
        # هر فیلد تاریخ فقط یک آیکون تقویم داخلی دارد؛ دکمه تکراری ساخته نمی‌شود.
        for attr_name in ("txtReportFrom", "txtReportTo", "txtTrackingDate"):
            old_widget = getattr(self.ui, attr_name, None)
            if old_widget is None or isinstance(old_widget, JalaliDateLineEdit):
                continue

            parent = old_widget.parentWidget()
            layout = parent.layout() if parent is not None else None
            new_widget = JalaliDateLineEdit(parent)
            new_widget.setObjectName(attr_name)
            new_widget.setMinimumWidth(max(120, old_widget.minimumWidth()))
            new_widget.setSizePolicy(old_widget.sizePolicy())
            new_widget.setText(old_widget.text())

            if not replace_widget_in_layout(layout, old_widget, new_widget):
                new_widget.deleteLater()
                old_widget.setPlaceholderText("شمسی: 1405/07/18 - خالی = همه تاریخ‌ها")
                install_calendar_action(old_widget)
                continue

            old_widget.hide()
            old_widget.setParent(None)
            old_widget.deleteLater()
            setattr(self.ui, attr_name, new_widget)

        today = jdatetime.date.today().strftime("%Y/%m/%d")

        # فیلدهای بازه تاریخ می‌توانند QLineEdit یا QDateEdit باشند.
        # در حالت QLineEdit تاریخ شمسی به شکل 14050718 یا 1405/07/18 وارد می‌شود.
        for date_widget in (self.ui.txtReportFrom, self.ui.txtReportTo):
            if hasattr(date_widget, "setDate"):
                # QDateEdit: تاریخ خالی یعنی بدون محدودیت
                no_date = QDate(1900, 1, 1)
                if hasattr(date_widget, "setMinimumDate"):
                    date_widget.setMinimumDate(no_date)
                if hasattr(date_widget, "setSpecialValueText"):
                    date_widget.setSpecialValueText("بدون محدودیت")
                date_widget.setDate(no_date)
                if hasattr(date_widget, "setCalendarPopup"):
                    date_widget.setCalendarPopup(True)
            else:
                # QLineEdit: هیچ متد مخصوص تقویم صدا زده نمی‌شود.
                date_widget.clear()
                if hasattr(date_widget, "setPlaceholderText"):
                    date_widget.setPlaceholderText("شمسی: 1405/07/18 - خالی = همه تاریخ‌ها")

        self.ui.txtTrackingDate.setText(today)

        self.ui.cmbReportUnit.clear()
        self.ui.cmbReportUnit.addItem("همه واحدها")
        for unit in sorted(PERSIAN_UNITS):
            self.ui.cmbReportUnit.addItem(unit)

        # موضوع‌های موجود در tblkar برای فیلتر گزارش
        self.ui.cmbReportTopic.clear()
        self.ui.cmbReportTopic.addItem("همه موضوعات")
        topic_conn = None
        topic_cursor = None
        try:
            topic_conn = get_connection()
            topic_cursor = topic_conn.cursor()
            topic_cursor.execute(
                "SELECT DISTINCT [mozooe] FROM [tblkar] "
                "WHERE [mozooe] IS NOT NULL AND Trim([mozooe]) <> '' "
                "ORDER BY [mozooe]"
            )
            for topic_row in topic_cursor.fetchall():
                topic = str(topic_row[0] or "").strip()
                if topic:
                    self.ui.cmbReportTopic.addItem(topic)
        except Exception:
            pass
        finally:
            if topic_cursor is not None:
                try:
                    topic_cursor.close()
                except Exception:
                    pass
            if topic_conn is not None:
                try:
                    topic_conn.close()
                except Exception:
                    pass

        self.ui.cmbReportStatus.clear()
        self.ui.cmbReportStatus.addItems([
            "همه وضعیت‌ها",
            "ثبت نشده",
            "در انتظار بررسی",
            "در حال انجام",
            "متوقف شده",
            "پایان",
        ])

        self.ui.cmbTrackingStatus.clear()
        self.ui.cmbTrackingStatus.addItems([
            "در انتظار بررسی",
            "در حال انجام",
            "متوقف شده",
            "پایان",
        ])

        table = self.ui.tblReportList
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        table.verticalHeader().setVisible(False)
        table.setAlternatingRowColors(True)
        table.verticalHeader().setDefaultSectionSize(34)
        table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Interactive
        )
        table.horizontalHeader().setMinimumHeight(40)
        table.setStyleSheet("""
            QTableWidget {
                background: white;
                alternate-background-color: #F7F9FC;
                gridline-color: #D6DCE3;
                font-family: "B Nazanin";
                font-size: 12pt;
                selection-background-color: #B8D7F0;
                selection-color: #000000;
            }
            QHeaderView::section {
                background-color: #E8EEF5;
                color: #1F2937;
                font-family: "B Nazanin";
                font-size: 13pt;
                font-weight: bold;
                padding: 6px;
                border: 1px solid #C7D0DB;
            }
        """)

        self.ui.btnSaveTracking.setEnabled(self.can_manage_tracking())
        if not self.can_manage_tracking():
            self.ui.btnSaveTracking.setToolTip(
                "ثبت پیگیری و تکمیل کار فقط برای واحد تعمیرات عمومی یا SuperAdmin مجاز است."
            )

        self.ui.btnRefreshReport.clicked.connect(self.load_report_data)
        self.ui.btnClearReportFilters.clicked.connect(self.clear_report_filters)
        self.ui.txtReportSearch.textChanged.connect(self.load_report_data)
        self.ui.cmbReportUnit.currentIndexChanged.connect(self.load_report_data)
        self.ui.cmbReportTopic.currentIndexChanged.connect(self.load_report_data)
        self.ui.cmbReportStatus.currentIndexChanged.connect(self.load_report_data)
        # اتصال امن سیگنال‌ها برای QLineEdit و QDateEdit
        if hasattr(self.ui.txtReportFrom, "dateChanged"):
            self.ui.txtReportFrom.dateChanged.connect(self.load_report_data)
        else:
            self.ui.txtReportFrom.textChanged.connect(self.load_report_data)
        if hasattr(self.ui.txtReportTo, "dateChanged"):
            self.ui.txtReportTo.dateChanged.connect(self.load_report_data)
        else:
            self.ui.txtReportTo.textChanged.connect(self.load_report_data)
        self.ui.tblReportList.itemSelectionChanged.connect(
            self.on_report_selection_changed
        )
        self.ui.btnSaveTracking.clicked.connect(self.save_tracking)
        self.ui.btnViewTrackingHistory.clicked.connect(self.view_tracking_history)

    @staticmethod
    def _date_digits(value):
        value = normalize_digits(value).strip()
        return "".join(ch for ch in value if ch.isdigit())

    @staticmethod
    def _jalali_filter_date(qdate):
        """QDate میلادی را به YYYYMMDD شمسی تبدیل می‌کند؛ 1900/01/01 یعنی بدون فیلتر."""
        if qdate == QDate(1900, 1, 1):
            return ""
        gregorian_date = qdate.toPython()
        return jdatetime.date.fromgregorian(date=gregorian_date).strftime("%Y%m%d")

    @staticmethod
    def _read_report_filter_date(widget):
        """خواندن تاریخ فیلتر از QLineEdit یا QDateEdit و برگرداندن YYYYMMDD شمسی."""
        try:
            if hasattr(widget, "date"):
                qdate = widget.date()
                if qdate == QDate(1900, 1, 1):
                    return ""
                return MainWindow._jalali_filter_date(qdate)

            raw = normalize_digits(widget.text()).strip()
            digits = "".join(ch for ch in raw if ch.isdigit())
            if not digits:
                return ""
            if len(digits) != 8:
                return "INVALID"

            year, month, day = int(digits[:4]), int(digits[4:6]), int(digits[6:8])
            # اعتبارسنجی واقعی تاریخ شمسی؛ از ورود تاریخ نامعتبر جلوگیری می‌شود.
            jdatetime.date(year, month, day)
            return digits
        except Exception:
            return "INVALID"

    @staticmethod
    def _format_jalali_date(value):
        if value is None or value == "":
            return ""
        # فیلد Access ممکن است از نوع Date/Time باشد.
        if isinstance(value, datetime):
            try:
                jd = jdatetime.date.fromgregorian(date=value.date())
                return jd.strftime("%Y/%m/%d")
            except Exception:
                return str(value)
        if isinstance(value, py_date):
            try:
                jd = jdatetime.date.fromgregorian(date=value)
                return jd.strftime("%Y/%m/%d")
            except Exception:
                return str(value)
        text = str(value).strip()
        # اگر تاریخ متنی با اسلش ذخیره شده باشد، همان را استاندارد می‌کنیم.
        normalized = normalize_digits(text)
        digits = "".join(ch for ch in normalized if ch.isdigit())
        if len(digits) == 8:
            return f"{digits[:4]}/{digits[4:6]}/{digits[6:8]}"
        # پشتیبانی از تاریخ میلادی متنی در صورت وجود داده‌های قدیمی.
        for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%m/%d/%Y"):
            try:
                gd = datetime.strptime(text[:19], fmt).date()
                return jdatetime.date.fromgregorian(date=gd).strftime("%Y/%m/%d")
            except Exception:
                pass
        return text

    @staticmethod
    def _completion_date_for_db(cursor, jalali_digits):
        """مقدار تاریخ پایان را متناسب با نوع فیلد tarikh در Access برمی‌گرداند."""
        year, month, day = int(jalali_digits[:4]), int(jalali_digits[4:6]), int(jalali_digits[6:8])
        jalali = jdatetime.date(year, month, day)
        gregorian = jalali.togregorian()
        try:
            for column in cursor.columns(table="tblkar"):
                if str(getattr(column, "column_name", "")).casefold() == "tarikh":
                    type_name = str(getattr(column, "type_name", "")).upper()
                    data_type = getattr(column, "data_type", None)
                    if any(word in type_name for word in ("DATE", "TIME")) or data_type in (91, 92, 93):
                        return datetime(gregorian.year, gregorian.month, gregorian.day)
                    if any(word in type_name for word in ("CHAR", "TEXT", "VARCHAR", "MEMO")):
                        return jalali.strftime("%Y/%m/%d")
                    if any(word in type_name for word in ("INT", "NUMERIC", "DECIMAL", "DOUBLE", "FLOAT", "REAL")) or data_type in (2, 3, 4, 5, 6, 7, 8):
                        return int(jalali_digits)
                    break
        except Exception:
            pass
        # مقدار پیش‌فرض برای فیلدهای متنی؛ از تبدیل اشتباه تاریخ شمسی به میلادی جلوگیری می‌کند.
        return jalali.strftime("%Y/%m/%d")

    def _get_latest_tracking(self):
        """آخرین وضعیت پیگیری را مستقیماً از فیلدهای tblkar می‌خواند."""
        latest = {}
        conn = None
        cursor = None
        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT [wonumber], [vaziyat], [tarikh], [sharhepey], [editor]
                FROM [tblkar]
            """)
            for row in cursor.fetchall():
                number = str(row[0] or "").strip()
                if number:
                    latest[number] = {
                        "status": str(row[1] or "ثبت نشده").strip() or "ثبت نشده",
                        "date": row[2],
                        "by": str(row[4] or "").strip(),
                        "description": str(row[3] or "").strip(),
                    }
        except Exception:
            return latest
        finally:
            if cursor is not None:
                try:
                    cursor.close()
                except Exception:
                    pass
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
        return latest

    def load_report_data(self, *_args):
        if not hasattr(self.ui, "tblReportList"):
            return

        conn = None
        cursor = None
        try:
            conn = get_connection()
            cursor = conn.cursor()

            sql = """
                SELECT [wonumber], [vahed], [tarikhdarkhast], [mozooe],
                       [mahalkarf], [mahalkara], [darkhastkonande], [sharh],
                       [vaziyat], [tarikh], [sharhepey], [payan]
                FROM [tblkar]
            """
            conditions = []
            params = []

            is_superadmin = self.usersecurity.casefold() == "superadmin"
            is_maintenance = self.is_maintenance_unit()

            # واحد تعمیرات عمومی باید همه درخواست‌ها را برای انجام کار ببیند.
            # سایر کاربران فقط محدوده مجاز خودشان را مشاهده می‌کنند.
            if not is_superadmin and not is_maintenance:
                if self.usersecurity.casefold() == "admin":
                    if self.user_vahed:
                        conditions.append("[vahed] = ?")
                        params.append(self.user_vahed)
                    else:
                        conditions.append("1 = 0")
                else:
                    conditions.append("[darkhastkonande] = ?")
                    params.append(self.username)

            selected_unit = self.ui.cmbReportUnit.currentText().strip()
            if selected_unit and selected_unit != "همه واحدها":
                conditions.append("[vahed] = ?")
                params.append(selected_unit)

            selected_topic = self.ui.cmbReportTopic.currentText().strip()
            if selected_topic and selected_topic != "همه موضوعات":
                conditions.append("[mozooe] = ?")
                params.append(selected_topic)

            if conditions:
                sql += " WHERE " + " AND ".join(conditions)
            sql += " ORDER BY [id] DESC"

            cursor.execute(sql, tuple(params))
            rows = cursor.fetchall()
        except Exception as exc:
            QMessageBox.warning(
                self, "گزارش کارها",
                f"دریافت گزارش با خطا مواجه شد:\n{exc}"
            )
            return
        finally:
            if cursor is not None:
                try:
                    cursor.close()
                except Exception:
                    pass
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

        latest = self._get_latest_tracking()
        search = self.ui.txtReportSearch.text().strip().casefold()
        from_date = self._read_report_filter_date(self.ui.txtReportFrom)
        to_date = self._read_report_filter_date(self.ui.txtReportTo)
        if from_date == "INVALID" or to_date == "INVALID":
            return
        if from_date and to_date and from_date > to_date:
            return
        wanted_status = self.ui.cmbReportStatus.currentText()

        display_rows = []
        for row in rows:
            wonumber = str(row[0] or "").strip()
            unit = str(row[1] or "").strip()
            date_raw = str(row[2] or "").strip()
            date_digits = self._date_digits(date_raw)
            topic = str(row[3] or "").strip()
            area = str(row[4] or "").strip()
            sub_area = str(row[5] or "").strip()
            requester = str(row[6] or "").strip()
            request_description = str(row[7] or "").strip()
            raw_status = str(row[8] or "").strip()
            # در رکوردهای قدیمی ممکن است وضعیت خالی باشد، اما فیلد payan درست باشد.
            payan_value = row[11] if len(row) > 11 else False
            is_completed = payan_value is True or str(payan_value).strip().casefold() in ("true", "1", "-1", "yes")
            status = normalize_status(raw_status) or ("پایان" if is_completed else "ثبت نشده")
            if is_completed:
                status = "پایان"
            followup_date = str(row[9] or "").strip()
            followup_description = str(row[10] or "").strip()

            if from_date and len(date_digits) == 8 and date_digits < from_date:
                continue
            if to_date and len(date_digits) == 8 and date_digits > to_date:
                continue
            if wanted_status != "همه وضعیت‌ها":
                wanted_key = normalize_status(wanted_status)
                status_key = normalize_status(status)
                if wanted_key == "پایان":
                    # هم وضعیت جدید و هم رکوردهای قدیمی با payan=True را شامل می‌شود.
                    if not (is_completed or status_key == "پایان"):
                        continue
                elif status_key != wanted_key:
                    continue

            haystack = " ".join([
                wonumber, unit, date_raw, topic, area, sub_area,
                requester, request_description, status, followup_description,
            ]).casefold()
            if search and search not in haystack and normalize_digits(search) not in normalize_digits(haystack):
                continue

            display_rows.append((
                wonumber, unit, date_raw, topic, area, requester,
                request_description, status, followup_date, followup_description,
            ))

        table = self.ui.tblReportList
        table.setRowCount(len(display_rows))
        for row_index, row in enumerate(display_rows):
            values = [
                str(row_index + 1), row[0], row[1],
                self._format_jalali_date(row[2]), row[3], row[4],
                row[5], row[6], row[7],
                self._format_jalali_date(row[8]), row[9],
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value or ""))
                item.setTextAlignment(
                    Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
                )
                if col == 1:
                    item.setData(Qt.ItemDataRole.UserRole, row[0])
                table.setItem(row_index, col, item)

        widths = [55, 105, 160, 115, 150, 150, 140, 320, 125, 125, 300]
        for col, width in enumerate(widths):
            table.setColumnWidth(col, width)

    def on_report_selection_changed(self):
        row = self.ui.tblReportList.currentRow()
        if row < 0:
            self.ui.lblSelectedWorkNo.setText("—")
            return
        item = self.ui.tblReportList.item(row, 1)
        number = item.data(Qt.ItemDataRole.UserRole) if item else ""
        if not number and item:
            number = item.text()
        self.ui.lblSelectedWorkNo.setText(str(number or "—"))

    def save_tracking(self):
        if not self.can_manage_tracking():
            QMessageBox.warning(
                self, "عدم دسترسی",
                "ثبت پیگیری و تکمیل کار فقط برای واحد تعمیرات عمومی یا SuperAdmin مجاز است."
            )
            return

        wonumber = self.ui.lblSelectedWorkNo.text().strip()
        if not wonumber or wonumber == "—":
            QMessageBox.warning(self, "انتخاب درخواست", "ابتدا یک درخواست از جدول گزارش انتخاب کنید.")
            return

        status = self.ui.cmbTrackingStatus.currentText().strip()
        date_text = self._date_digits(self.ui.txtTrackingDate.text())
        note = self.ui.txtTrackingNote.toPlainText().strip()
        is_completed = status.casefold() in ("پایان", "تکمیل شده")

        if is_completed:
            if len(date_text) != 8 or not date_text.isdigit():
                QMessageBox.warning(
                    self, "تاریخ پایان نامعتبر",
                    "برای پایان کار، تاریخ شمسی را به صورت ۸ رقمی وارد کنید؛ مثال: ۱۴۰۵۰۷۲۲"
                )
                return
            try:
                jdatetime.date(int(date_text[:4]), int(date_text[4:6]), int(date_text[6:8]))
            except ValueError:
                QMessageBox.warning(self, "تاریخ پایان نامعتبر", "تاریخ پایان کار معتبر نیست.")
                return

        if not note:
            QMessageBox.warning(self, "شرح پیگیری", "شرح پیگیری یا نتیجه انجام کار را وارد کنید.")
            return

        conn = None
        cursor = None
        try:
            conn = get_connection()
            cursor = conn.cursor()

            # تاریخ پایان فقط هنگام انتخاب وضعیت «پایان» تغییر می‌کند؛
            # با بازگرداندن کار به وضعیت دیگر، تاریخ قبلی حفظ می‌شود.
            if is_completed:
                completion_date = self._completion_date_for_db(cursor, date_text)
                cursor.execute("""
                    UPDATE [tblkar]
                    SET [vaziyat] = ?,
                        [payan] = ?,
                        [tarikh] = ?,
                        [editor] = ?,
                        [sharhepey] = ?
                    WHERE [wonumber] = ?
                """, ("پایان", True, completion_date, self.username, note, wonumber))
            else:
                cursor.execute("""
                    UPDATE [tblkar]
                    SET [vaziyat] = ?,
                        [payan] = ?,
                        [editor] = ?,
                        [sharhepey] = ?
                    WHERE [wonumber] = ?
                """, (status, False, self.username, note, wonumber))

            if cursor.rowcount == 0:
                QMessageBox.warning(
                    self, "ثبت پیگیری",
                    "درخواست موردنظر در tblkar پیدا نشد و اطلاعات ذخیره نشد."
                )
                conn.rollback()
                return

            conn.commit()
        except Exception as exc:
            if conn is not None:
                try:
                    conn.rollback()
                except Exception:
                    pass
            QMessageBox.critical(self, "ثبت پیگیری ناموفق", f"اطلاعات ذخیره نشد:\n{exc}")
            return
        finally:
            if cursor is not None:
                try:
                    cursor.close()
                except Exception:
                    pass
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

        QMessageBox.information(
            self, "ثبت شد",
            "نتیجه پایان کار ثبت شد؛ فیلدهای payan، tarikh و editor نیز به‌روزرسانی شدند."
            if is_completed else "اطلاعات پیگیری با موفقیت ثبت شد."
        )
        self.ui.txtTrackingNote.clear()
        self.ui.txtTrackingDate.setText(jdatetime.date.today().strftime("%Y/%m/%d"))
        self.load_report_data()

    def view_tracking_history(self):
        wonumber = self.ui.lblSelectedWorkNo.text().strip()
        if not wonumber or wonumber == "—":
            QMessageBox.information(self, "سوابق پیگیری", "ابتدا یک درخواست را انتخاب کنید.")
            return

        conn = None
        cursor = None
        try:
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT [tarikh], [vaziyat], [sharhepey], [editor], [payan]
                FROM [tblkar]
                WHERE [wonumber] = ?
            """, (wonumber,))
            row = cursor.fetchone()
        except Exception as exc:
            QMessageBox.warning(self, "سوابق پیگیری", f"خواندن اطلاعات انجام نشد:\n{exc}")
            return
        finally:
            if cursor is not None:
                try:
                    cursor.close()
                except Exception:
                    pass
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

        if not row:
            QMessageBox.information(self, "سوابق پیگیری", "برای این درخواست اطلاعاتی ثبت نشده است.")
            return

        completion_date, status, description, editor, is_completed = row
        date_display = self._format_jalali_date(completion_date) or "ثبت نشده"
        lines = [
            f"شماره درخواست: {wonumber}",
            f"وضعیت فعلی: {status or 'ثبت نشده'}",
            f"پایان کار: {'بله' if bool(is_completed) else 'خیر'}",
            f"تاریخ پایان: {date_display}",
            f"تغییردهنده وضعیت: {editor or 'ثبت نشده'}",
            f"شرح پیگیری / نتیجه کار: {description or ''}",
        ]
        QMessageBox.information(self, f"اطلاعات پیگیری درخواست {wonumber}", "\n".join(lines))

    def clear_report_filters(self):
        self.ui.txtReportSearch.clear()
        self.ui.cmbReportUnit.setCurrentIndex(0)
        self.ui.cmbReportTopic.setCurrentIndex(0)
        self.ui.cmbReportStatus.setCurrentIndex(0)
        for date_widget in (self.ui.txtReportFrom, self.ui.txtReportTo):
            if hasattr(date_widget, "setDate"):
                date_widget.setDate(QDate(1900, 1, 1))
            else:
                date_widget.clear()
        self.load_report_data()
