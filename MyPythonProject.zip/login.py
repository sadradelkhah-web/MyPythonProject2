import sys

from PySide6.QtCore import QSettings, Qt
from PySide6.QtWidgets import QApplication, QDialog, QMessageBox

from ui_login import Ui_login
from db_config import get_connection
from main import MainWindow


class LoginDialog(QDialog):
    def __init__(self):
        super().__init__()

        self.ui = Ui_login()
        self.ui.setupUi(self)
        self.setLayoutDirection(Qt.RightToLeft)

        self.current_user = None

        self.settings = QSettings("MyPythonProject", "MyApp")
        saved_username = self.settings.value("last_username", "")
        self.ui.txtUsername.setText(str(saved_username))

        self.ui.btnLogin.clicked.connect(self.login)
        self.ui.btnExit.clicked.connect(self.reject)
        self.ui.txtPassword.returnPressed.connect(self.login)

        if self.ui.txtUsername.text().strip():
            self.ui.txtPassword.setFocus()
        else:
            self.ui.txtUsername.setFocus()

    def login(self):
        username = self.ui.txtUsername.text().strip()
        password = self.ui.txtPassword.text()

        if not username:
            QMessageBox.warning(self, "ورود", "نام کاربری را وارد کنید.")
            self.ui.txtUsername.setFocus()
            return

        if not password:
            QMessageBox.warning(self, "ورود", "رمز عبور را وارد کنید.")
            self.ui.txtPassword.setFocus()
            return

        connection = None
        cursor = None

        try:
            connection = get_connection()
            cursor = connection.cursor()

            cursor.execute(
                """
                SELECT [userid], [username], [UserLogin], [password],
                       [usersecurity], [Samat], [vahed], [Userlevel]
                FROM [tbluser]
                WHERE [UserLogin] = ? AND [password] = ?
                """,
                username,
                password,
            )

            user = cursor.fetchone()

            if user is None:
                QMessageBox.warning(
                    self,
                    "ورود ناموفق",
                    "نام کاربری یا رمز عبور صحیح نیست.",
                )
                self.ui.txtPassword.clear()
                self.ui.txtPassword.setFocus()
                return

            self.current_user = {
                "userid": user[0],
                "username": user[1],
                "UserLogin": user[2],
                "usersecurity": user[4],
                "Samat": user[5],
                "vahed": user[6],
                "Userlevel": user[7],
            }

            self.settings.setValue("last_username", username)
            self.accept()

        except Exception as exc:
            QMessageBox.critical(
                self,
                "خطای اتصال",
                f"اتصال به پایگاه داده یا بررسی اطلاعات ورود با خطا مواجه شد:\n\n{exc}",
            )
        finally:
            if cursor is not None:
                try:
                    cursor.close()
                except Exception:
                    pass
            if connection is not None:
                try:
                    connection.close()
                except Exception:
                    pass

def main():
    app = QApplication(sys.argv)
    app.setLayoutDirection(Qt.LayoutDirection.RightToLeft)

    login = LoginDialog()
    if login.exec() != QDialog.DialogCode.Accepted or login.current_user is None:
        return 0

    main_window = MainWindow(login.current_user)
    main_window.showMaximized()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
